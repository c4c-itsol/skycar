import esMessages from '../locales/es_ES';

const EsLang = {
  messages: {
    ...esMessages,
  },
  locale: 'es-ES',
};
export default EsLang;
