import React from 'react'

function managecustomer() {
  return (
    <div>managecustomer</div>
  )
}

export default managecustomer