import React from "react";
import { NavLink } from "react-router-dom";

const CustomerData = [
    {
        Customer_Name: 'Dhruti Rathod',
        Phone: '1234567890',
        Address: 'Navsari',
        Driving_Licence_Number: 'GJ-0619850034761',
        Action :(
          <div className="table-action-wrap"> 
            <NavLink to><i className="simple-icon-pencil icns"/></NavLink>
            <NavLink to><i className="simple-icon-doc icns"/></NavLink>
            <NavLink to><i className="simple-icon-trash icns"/></NavLink>
          </div>
        )
    },
    {
        Customer_Name: 'Deep Rathod',
        Phone: '1234567890',
        Address: 'Navsari',
        Driving_Licence_Number: 'GJ-0619850034761',
        Action :(
          <div className="table-action-wrap"> 
            <NavLink to><i className="simple-icon-pencil icns"/></NavLink>
            <NavLink to><i className="simple-icon-doc icns"/></NavLink>
            <NavLink to><i className="simple-icon-trash icns"/></NavLink>
          </div>
        )
    },
    {
      Customer_Name: 'Minaxi Rathod',
      Phone: '1234567890',
        Address: 'Navsari',
        Driving_Licence_Number: 'GJ-0619850034761',
      Action :(
        <div className="table-action-wrap"> 
          <NavLink to><i className="simple-icon-pencil icns"/></NavLink>
          <NavLink to><i className="simple-icon-doc icns"/></NavLink>
          <NavLink to><i className="simple-icon-trash icns"/></NavLink>
        </div>
      )
    },
    {
        Customer_Name: 'Hansraj Rathod',
        Phone: '1234567890',
        Address: 'Navsari',
        Driving_Licence_Number: 'GJ-0619850034761',
        Action :(
          <div className="table-action-wrap"> 
            <NavLink to><i className="simple-icon-pencil icns"/></NavLink>
            <NavLink to><i className="simple-icon-doc icns"/></NavLink>
            <NavLink to><i className="simple-icon-trash icns"/></NavLink>
          </div>
        )
      },
      {
        Customer_Name: 'Dhruti Rathod',
        Phone: '1234567890',
        Address: 'Navsari',
        Driving_Licence_Number: 'GJ-0619850034761',
        Action :(
          <div className="table-action-wrap"> 
            <NavLink to><i className="simple-icon-pencil icns"/></NavLink>
            <NavLink to><i className="simple-icon-doc icns"/></NavLink>
            <NavLink to><i className="simple-icon-trash icns"/></NavLink>
          </div>
        )
    },
    {
        Customer_Name: 'Deep Rathod',
        Phone: '1234567890',
        Address: 'Navsari',
        Driving_Licence_Number: 'GJ-0619850034761',
        Action :(
          <div className="table-action-wrap"> 
            <NavLink to><i className="simple-icon-pencil icns"/></NavLink>
            <NavLink to><i className="simple-icon-doc icns"/></NavLink>
            <NavLink to><i className="simple-icon-trash icns"/></NavLink>
          </div>
        )
    },
    {
      Customer_Name: 'Minaxi Rathod',
      Phone: '1234567890',
        Address: 'Navsari',
        Driving_Licence_Number: 'GJ-0619850034761',
      Action :(
        <div className="table-action-wrap"> 
          <NavLink to><i className="simple-icon-pencil icns"/></NavLink>
          <NavLink to><i className="simple-icon-doc icns"/></NavLink>
          <NavLink to><i className="simple-icon-trash icns"/></NavLink>
        </div>
      )
    },
    {
        Customer_Name: 'Hansraj Rathod',
        Phone: '1234567890',
        Address: 'Navsari',
        Driving_Licence_Number: 'GJ-0619850034761',
        Action :(
          <div className="table-action-wrap"> 
            <NavLink to><i className="simple-icon-pencil icns"/></NavLink>
            <NavLink to><i className="simple-icon-doc icns"/></NavLink>
            <NavLink to><i className="simple-icon-trash icns"/></NavLink>
          </div>
        )
      },
  ];
  
  export default CustomerData;
  