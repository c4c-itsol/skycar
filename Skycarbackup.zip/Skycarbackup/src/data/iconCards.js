const data = [
  { title: 'dashboard.cars', icon: 'iconsminds-car', value: 10 },
  {
    title: 'dashboard.customer',
    icon: 'simple-icon-user',
    value: 20,
  },
  {
    title: 'dashboard.booking',
    icon: 'simple-icon-calendar',
    value: 30,
  },
  { title: 'dashboard.transaction', icon: 'iconsminds-coins', value: 35 },
];
export default data;
